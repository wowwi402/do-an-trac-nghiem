let timerInterval;
let timeLeft = 15;
let questions = [];
let currentQuestion = 0;
let score = 0;

const quizContainer = document.getElementById("quiz-container");
const user = localStorage.getItem("loggedInUser");
document.getElementById("user-name").textContent = user;

const correctSound = new Audio("correct.mp3");
const wrongSound = new Audio("wrong.mp3");

// Kiểm tra đăng nhập
if (!user) {
  window.location.href = "login.html";
}

// Tải câu hỏi từ file JSON
fetch("questions.json")
  .then((response) => response.json())
  .then((data) => {
    questions = data;
    // Đợi người dùng nhấn "Bắt đầu"
  })
  .catch((error) => {
    quizContainer.innerHTML = "Không thể tải câu hỏi 😥";
    console.error(error);
  });

// Bắt đầu bài trắc nghiệm
function startQuiz() {
  document.getElementById("welcome-screen").style.display = "none";
  document.getElementById("quiz-container").style.display = "block";
  document.getElementById("timer").style.display = "block";
  document.getElementById("score-display").textContent = `🧮 Điểm: ${score}`;
  loadQuestion();
}

// Tải câu hỏi hiện tại
function loadQuestion() {
  const question = questions[currentQuestion];

  quizContainer.innerHTML = "";
  quizContainer.classList.add("animate-fade-in");
  setTimeout(() => quizContainer.classList.remove("animate-fade-in"), 500);

  const progress = document.createElement("div");
  progress.className = "text-sm text-gray-600 mb-2 font-semibold";
  progress.textContent = `Câu ${currentQuestion + 1} / ${questions.length}`;
  quizContainer.appendChild(progress);

  const questionElement = document.createElement("div");
  questionElement.innerHTML = `<strong class="text-xl text-gray-800">Câu ${currentQuestion + 1}:</strong> ${question.question}`;
  quizContainer.appendChild(questionElement);

  const optionsContainer = document.createElement("div");
  optionsContainer.classList.add("mt-4");

  const options = question.type === "multiple_choice" ? question.options : ["True", "False"];
  options.forEach((option) => {
    const button = document.createElement("button");
    button.textContent = option;
    button.className =
      "w-full bg-white hover:bg-indigo-100 border border-indigo-300 text-indigo-700 font-semibold py-3 px-5 mb-3 rounded-xl shadow transition duration-200";
    button.onclick = () => handleAnswer(option);
    optionsContainer.appendChild(button);
  });

  quizContainer.appendChild(optionsContainer);
  startTimer();
}

// Đếm ngược thời gian
function startTimer() {
  clearInterval(timerInterval);
  timeLeft = 15;
  document.getElementById("timer").textContent = `⏳ Còn ${timeLeft}s`;

  timerInterval = setInterval(() => {
    timeLeft--;
    document.getElementById("timer").textContent = `⏳ Còn ${timeLeft}s`;

    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      alert("⏰ Hết giờ câu hỏi này!");
      handleAnswer(null); // Không trả lời
    }
  }, 1000);
}

// Xử lý câu trả lời
function handleAnswer(selected) {
  clearInterval(timerInterval);
  const correct = questions[currentQuestion].correctAnswer;

  if (selected === correct) {
    score++;
    correctSound.play();
    alert("✅ Chính xác!");
  } else if (selected === null) {
    wrongSound.play();
    alert(`❌ Bạn đã không trả lời. Đáp án đúng là: ${correct}`);
  } else {
    wrongSound.play();
    alert(`❌ Sai rồi! Đáp án đúng là: ${correct}`);
  }

  document.getElementById("score-display").textContent = `🧮 Điểm: ${score}`;
  currentQuestion++;

  if (currentQuestion < questions.length) {
    loadQuestion();
  } else {
    showResult();
  }
}

// Hiển thị kết quả và lưu
function showResult() {
  saveResult(user, score, questions.length);

  quizContainer.innerHTML = `
    <h2 class="text-2xl font-bold text-green-600 mb-2">🎉 Bạn đã hoàn thành!</h2>
    <p class="text-lg text-gray-700 mb-4">Điểm số: ${score} / ${questions.length}</p>
    <div class="flex gap-4">
      <button onclick="restartQuiz()" class="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded shadow">🔄 Làm lại</button>
      <button onclick="goToHistory()" class="bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded shadow">📜 Xem lịch sử</button>
    </div>
  `;

  document.getElementById("timer").textContent = "";
}

// Lưu lịch sử làm bài
function saveResult(username, score, total) {
  const result = {
    username,
    score,
    total,
    date: new Date().toISOString(),
  };

  let results = JSON.parse(localStorage.getItem("quizResults")) || [];
  results.push(result);
  localStorage.setItem("quizResults", JSON.stringify(results));
}

// 👉 Chuyển sang trang lịch sử
function goToHistory() {
  window.location.href = "history.html";
}

// Làm lại
function restartQuiz() {
  currentQuestion = 0;
  score = 0;
  document.getElementById("quiz-container").style.display = "block";
  document.getElementById("timer").style.display = "block";
  loadQuestion();
}

// Đăng xuất
function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "login.html";
}
