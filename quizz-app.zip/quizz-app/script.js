let timerInterval;
let timeLeft = 10; // ⏱️ thời gian mỗi câu hỏi (giây)
let questions = [];
let currentQuestion = 0;
let score = 0;
const quizContainer = document.getElementById('quiz-container');

// Đọc dữ liệu JSON
fetch('questions.json')
    .then(response => response.json())
    .then(data => {
        questions = data;
        loadQuestion();
    })
    .catch(error => {
        quizContainer.innerHTML = 'Không thể tải câu hỏi 😥';
        console.error(error);
    });

// Hiển thị từng câu hỏi
function loadQuestion() {
    const question = questions[currentQuestion];
    quizContainer.innerHTML = '';

    const questionElement = document.createElement('div');
    questionElement.innerHTML = `<strong>Câu ${currentQuestion + 1}:</strong> ${question.question}`;
    quizContainer.appendChild(questionElement);

    const optionsContainer = document.createElement('div');

    if (question.type === 'multiple_choice') {
        question.options.forEach(option => {
            const button = document.createElement('button');
            button.textContent = option;
            button.className = "bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 m-2 rounded";
            button.onclick = () => handleAnswer(option);
            optionsContainer.appendChild(button);
        });
    } else if (question.type === 'true_false') {
        ['True', 'False'].forEach(option => {
            const button = document.createElement('button');
            button.textContent = option;
            button.className = "bg-green-500 hover:bg-green-600 text-white py-2 px-4 m-2 rounded";
            button.onclick = () => handleAnswer(option);
            optionsContainer.appendChild(button);
        });
    }

    quizContainer.appendChild(optionsContainer);
    startTimer(); // ✅ GỌI HÀM ĐẾM NGƯỢC
}

// Xử lý trả lời
function handleAnswer(selected) {
    clearInterval(timerInterval); // ⛔ dừng đếm ngược

    const correct = questions[currentQuestion].correctAnswer;

    if (selected === correct) {
        score++;
        alert('✅ Chính xác!');
    } else if (selected === null) {
        alert(`❌ Bạn đã không trả lời. Đáp án đúng là: ${correct}`);
    } else {
        alert(`❌ Sai rồi! Đáp án đúng là: ${correct}`);
    }

    currentQuestion++;

    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        showResult();
    }
}

// Hiện kết quả cuối
function showResult() {
    quizContainer.innerHTML = `
        <h2>🎉 Bạn đã hoàn thành!</h2>
        <p>Điểm số: ${score} / ${questions.length}</p>
    `;
    document.getElementById("timer").textContent = "";
}

// Đếm ngược mỗi câu hỏi
function startTimer() {
    clearInterval(timerInterval);
    timeLeft = 10;
    document.getElementById("timer").textContent = `⏳ Còn ${timeLeft}s`;

    timerInterval = setInterval(() => {
        timeLeft--;
        document.getElementById("timer").textContent = `⏳ Còn ${timeLeft}s`;

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            alert("⏰ Hết giờ câu hỏi này!");
            handleAnswer(null); // xử lý không trả lời
        }
    }, 1000);
}

// Kiểm tra đăng nhập
if (!localStorage.getItem("loggedInUser")) {
  window.location.href = "login.html";
}

// Hàm đăng xuất
function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "login.html";
}
