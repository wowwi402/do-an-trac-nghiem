// login.js
// Tài khoản mẫu
const users = [
  { username: "admin", password: "123456" },
  { username: "user", password: "abc123" }
];

function login() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const error = document.getElementById("error");

  const found = users.find(u => u.username === username && u.password === password);

  if (found) {
    localStorage.setItem("loggedInUser", username);
    window.location.href = "index.html";
  } else {
    error.textContent = "❌ Tên đăng nhập hoặc mật khẩu sai!";
  }
}

