// Danh sách người dùng mẫu (có thể mở rộng hoặc thay bằng dữ liệu từ backend nếu cần)
const users = [
  { username: "admin", password: "123456", role: "admin" },
  { username: "user1", password: "abc123", role: "user" },
  { username: "test", password: "test", role: "user" }
];

function login() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;

  const storedUsers = JSON.parse(localStorage.getItem("userList")) || [];

  const user = storedUsers.find(u => u.username === username && u.password === password);

  if (user) {
    localStorage.setItem("loggedInUser", user.username);
    localStorage.setItem("userRole", user.role);
    window.location.href = "index.html";
  } else {
    document.getElementById("error-message").textContent = "❌ Sai tên đăng nhập hoặc mật khẩu!";
  }
}

